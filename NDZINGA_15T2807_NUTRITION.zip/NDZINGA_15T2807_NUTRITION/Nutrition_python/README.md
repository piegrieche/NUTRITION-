# Application de gestion de plans de repas et de buffets

Cette application est construite avec Flask et utilise une base de données MySQL pour stocker les données.

## Prérequis
* Python 3.7
* MySQL
* Docker (facultatif)

## Installation
1. Cloner le dépôt Git
2. Créer un fichier `requirements.txt` avec les dépendances suivantes :
   * Flask
   * marshmallow
   * sqlalchemy
   * pymysql
3. Installer les dépendances avec `pip install -r requirements.txt`
4. Configurer la base de données MySQL avec les informations de connexion appropriées

## Lancer l'application
1. Lancer l'application avec `python Nutrition_python.py`
2. Accéder à l'application à l'adresse `https://github.com/piegrieche/NUTRITION-'                

                  
1. Construire l'image Docker avec `docker build -t Nutrition_python .`
2. Lancer le conteneur avec `docker run -p 5000:5000 Nutrition_python`

## API Endpoints
* `/users` : Créer un utilisateur
* `/meal-plans` : Créer un plan de repas
* `/meals` : Créer un repas
* `/buffets` : Créer un buffet
* `/ceremonies` : Créer une cérémonie
