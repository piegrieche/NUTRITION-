# Nutrition_java

Cette application est une API REST pour gérer des plans de repas et des cérémonies.

## Prérequis
* Java 17
* Maven ou Gradle
* MySQL

## Installation
1. Cloner le dépôt Git
2. Exécuter la commande `mvn clean package` (ou `gradle build`) pour construire le projet
3. Créer une base de données MySQL avec le nom `nutrition_db`
4. Configurer les propriétés de connexion à la base de données dans le fichier `application.properties`

## Lancer l'application
1. Exécuter la commande `java -jar target/Nutrition_java.jar` pour lancer l'application
2. Accéder à l'API à l'adresse `https://github.com/piegrieche/NUTRITION-'             

         
1. Construire l'image Docker avec la commande `docker build -t Nutrition_java .`
2. Lancer le conteneur avec la commande `docker run -p 8080:8080 Nutrition_java`

## API Endpoints
* `POST /api/users` : Créer un nouvel utilisateur
* `POST /api/meal-plans` : Créer un nouveau plan de repas
* `POST /api/meals` : Créer un nouveau repas
* `POST /api/buffets` : Créer un nouveau buffet
* `POST /api/ceremonies` : Créer une nouvelle cérémonie
